const data = [
  {
    title: "Home",
    url: "/",
  },
  {
    title: "About",
    url: "#about",
  },
  {
    title: "Roadmap",
    url: "#roadmap",
  },
  {
    title: "Faq",
    url: "#faq",
  },

 
];

export default data;
