const data = [
  {
    title: "Metaverse",
    postCount: "03",
    url: "#",
  },
  {
    title: "Crypto",
    postCount: "12",
    url: "#",
  },
  {
    title: "Launchpad",
    postCount: "05",
    url: "#",
  },
  {
    title: "Web 3.0",
    postCount: "02",
    url: "#",
  },
  {
    title: "Farming",
    postCount: "04",
    url: "#",
  },
  {
    title: "Staking",
    postCount: "07",
    url: "#",
  },
];

export default data;
