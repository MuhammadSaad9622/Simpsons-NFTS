import nftImg1 from "../images/nft/446.png";
import nftImg2 from "../images/nft/453.png";
import nftImg3 from "../images/nft/883.png";
import nftImg4 from "../images/nft/921.png";
import nftImg5 from "../images/nft/1077.png";
import nftImg6 from "../images/nft/1243.png";
import nftImg7 from "../images/nft/4032.png";
// import nftImg8 from "../images/nft/cat8.png";
// import nftImg9 from "../images/nft/cat9.png";
// import nftImg10 from "../images/nft/cat10.png";
// import nftImg11 from "../images/nft/cat11.png";
// import nftImg12 from "../images/nft/cat12.png";

const data = [
  nftImg1,
  nftImg2,
  nftImg3,
  nftImg4,
  nftImg5,
  nftImg6,
  nftImg7,
  // nftImg8,
  // nftImg9,
  // nftImg10,
  // nftImg11,
  // nftImg12,
];

export default data;
