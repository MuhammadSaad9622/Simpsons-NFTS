import shapeIcon from "../images/icon/mint_live_icon.svg";

const data = [
  {
    icon: shapeIcon,
    text: "Mint Is Live",
  },
  {
    icon: shapeIcon,
    text: "Presale End",
  },
  {
    icon: shapeIcon,
    text: "Mint Is Live",
  },
  {
    icon: shapeIcon,
    text: "Presale End",
  },
  {
    icon: shapeIcon,
    text: "Mint Is Live",
  },
  {
    icon: shapeIcon,
    text: "Presale End",
  },
  {
    icon: shapeIcon,
    text: "Mint Is Live",
  },
  {
    icon: shapeIcon,
    text: "Presale End",
  },
  {
    icon: shapeIcon,
    text: "Mint Is Live",
  },
  {
    icon: shapeIcon,
    text: "Presale End",
  },
  {
    icon: shapeIcon,
    text: "Mint Is Live",
  },
  {
    icon: shapeIcon,
    text: "Presale End",
  },
];

export default data;
