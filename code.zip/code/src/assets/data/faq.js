const data = [
  {
    title: "How can I purchase an NFT on the XRP Ledger?",
    text: "To purchase an NFT on the XRP Ledger, you will need to create a Xumm Wallet.",
  },
  {
    title: "Where can I purchase your NFTs?",
    text: "You can purchase our NFTs on the OnXrp.com platform.",
  },
  {
    title: "How much will the NFT cost?",
    text: "Our firts 1000 NFTs is FREE and the last 4000 NFT will be priced at around 1 $XRP.",
  },
  {
    title: "I have more questions about your project. How can I get in touch?",
    text: "You can send us a message on Twitter or Discord. Additionally, you can discuss with the community in our chat.",
  },

 
];

export default data;
