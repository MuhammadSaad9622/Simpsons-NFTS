import { FiCheck, FiMinus } from "react-icons/fi";
import thumb1 from "../../images/nft/10.png";
import thumb2 from "../../images/nft/14.png";
import thumb3 from "../../images/nft/32.png";
import thumb4 from "../../images/nft/39.png"; 

const data = [
  {
    title: "Grow -> Mint -> Vibe -> Thrive -> REDACTED",
    thumb: thumb1,
   
  },
 


  
];

export default data;
