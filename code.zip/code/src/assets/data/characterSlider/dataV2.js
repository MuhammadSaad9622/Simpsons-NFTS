import character1 from "../../images/nft/n1.jpg";
import character2 from "../../images/nft/n2.jpg";
import character3 from "../../images/nft/n3.jpg";
import character4 from "../../images/nft/n4.jpg";
import character5 from "../../images/nft/n5.jpg";

const data = [
  {
    thumb: character1,
  },
  {
    thumb: character2,
  },
  {
    thumb: character3,
  },
  {
    thumb: character4,
  },
  {
    thumb: character5,
  },
  {
    thumb: character4,
  },
  {
    thumb: character1,
  },
  {
    thumb: character2,
  },
];

export default data;
