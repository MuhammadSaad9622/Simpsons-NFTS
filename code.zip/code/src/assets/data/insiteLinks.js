export const footerLinksV1 = [
  {
    title: "Home",
    url: "/",
  },
  {
    title: "About",
    url: "#about",
  },
  {
    title: "Roadmap",
    url: "#roadmap",
  },
  {
    title: "Team",
    url: "#team",
  },
  {
    title: "FAQ",
    url: "#faq",
  },
];
