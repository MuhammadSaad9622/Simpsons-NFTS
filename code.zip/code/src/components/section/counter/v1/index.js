import CoinInfoCounter from "./Counter";

export default CoinInfoCounter