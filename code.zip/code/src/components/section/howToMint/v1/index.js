import HowToMint from "./HowToMint";


export default HowToMint;