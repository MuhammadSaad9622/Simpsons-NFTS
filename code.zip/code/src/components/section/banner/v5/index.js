import Banner1 from "./Banner";

export default  Banner1;