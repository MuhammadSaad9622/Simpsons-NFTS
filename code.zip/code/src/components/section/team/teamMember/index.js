import TeamMember from "./TeamMember";

export default TeamMember;