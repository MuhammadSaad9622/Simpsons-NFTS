import BlogDetails from "./BlogDetails";

export default BlogDetails;
