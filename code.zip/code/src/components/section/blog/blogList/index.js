import BlogList from "./BlogList";

export default BlogList;