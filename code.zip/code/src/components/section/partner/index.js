import Partner from "./Partner";

export default Partner;