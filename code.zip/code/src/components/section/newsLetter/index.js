import NewsLetter from "./NewsLetter";

export default NewsLetter;
