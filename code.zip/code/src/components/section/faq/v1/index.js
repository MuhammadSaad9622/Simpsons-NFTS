import FAQ from "./Faq";

export default FAQ;
