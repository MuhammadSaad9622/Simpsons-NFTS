import CTA from "./Cta";

export default CTA;
