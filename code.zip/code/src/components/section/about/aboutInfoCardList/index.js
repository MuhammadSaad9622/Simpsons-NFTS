import AboutInfoCardList from "./AboutInfoCardList"

export default AboutInfoCardList;