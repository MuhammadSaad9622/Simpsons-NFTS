import Mint from "./Mint";

export default Mint;
