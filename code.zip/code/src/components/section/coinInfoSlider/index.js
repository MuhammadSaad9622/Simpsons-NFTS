import CoinInfoSlider from "./CoinInfoSlider";

export default CoinInfoSlider;
