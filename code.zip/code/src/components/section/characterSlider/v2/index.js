import CharacterSlide from "./CharacterSlide"

export default CharacterSlide;