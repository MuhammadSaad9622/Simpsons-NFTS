import CharacterSlider from "./CharacterSlider";

export default CharacterSlider;