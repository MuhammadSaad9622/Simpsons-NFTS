import foooterBottom from "./FooterBottom";

export default foooterBottom;
