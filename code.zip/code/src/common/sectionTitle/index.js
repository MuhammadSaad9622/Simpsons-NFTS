import SectionTitle from "./SectionTitle";

export default SectionTitle;