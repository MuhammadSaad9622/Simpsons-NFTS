import MintNowModal from "./MintNowModal";

export default MintNowModal;
